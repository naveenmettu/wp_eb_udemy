<?php

namespace DeliciousBrains\WP_Offload_S3\Upgrades\Exceptions;

class Too_Many_Errors_Exception extends \Exception {

}